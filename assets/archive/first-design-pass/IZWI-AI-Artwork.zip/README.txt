IZWI AI concept presentation and artwork

12-slide deck: https://www.figma.com/slides/4SiLtJaa01WcjaD44LcLp9
Editable poster and 3 concept mockups: https://www.figma.com/design/IVJa5NlJJINI75Lyc9Eklw

PowerPoint uses slide images to preserve the template appearance, plus fade transitions. Native object animations are not included. Editable layers are in Figma. Presenter notes include sources and financial assumptions. Pricing is illustrative, not a customer-validated offer. Demo portraits are AI-generated fictional people.

Artwork PNGs are exported at up to 1600px. Use Figma export settings for larger production exports.
